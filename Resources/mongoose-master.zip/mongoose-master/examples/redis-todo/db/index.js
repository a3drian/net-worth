'use strict';

const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/redis-todo');
