## Contributing

Please read all about contributing [here](https://github.com/Automattic/mongoose/blob/master/CONTRIBUTING.md).