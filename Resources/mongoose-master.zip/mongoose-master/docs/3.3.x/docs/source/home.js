
var package = require('./../../package.json')

module.exports = {
    package: package
  , title: 'ODM'
}
