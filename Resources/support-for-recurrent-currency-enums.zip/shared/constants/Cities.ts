export enum CITY {
	BRASOV = 'Brașov',
	BUCURESTI = 'București',
	CLUJ = 'Cluj-Napoca',
	LONDON = 'London',
	TIMISOARA = 'Timișoara',
	OTHER = 'Other'
}
