export enum LOCATION {
	CARREFOUR = 'Carrefour',
	LIDL = 'LIDL',
	OMV = 'OMV',
	PROFI = 'Profi',
	SELGROS = 'Selgros',
	OTHER = 'Other'
}
