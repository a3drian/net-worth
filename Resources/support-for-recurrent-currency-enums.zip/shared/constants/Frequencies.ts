export enum FREQUENCY {
	WEEKLY = 'Weekly',
	MONTHLY = 'Monthly',
	YEARLY = 'Yearly'
}
